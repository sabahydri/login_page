

var up_button=document.getElementById("up_button");
up_button.addEventListener("click",change);

var sign_up=document.getElementById("sign_up");
var sign_in=document.getElementById("sign_in");
var signIn=document.getElementById("signIn");
var signUp=document.getElementById("signUp");

function change(){

    var sign_up=document.getElementById("sign_up");
    var sign_in=document.getElementById("sign_in");
    var signIn=document.getElementById("signIn");
    var signUp=document.getElementById("signUp");
sign_in.remove();
sign_up.remove();
document.getElementById("right_back").style.backgroundColor="#f98e1d";
document.getElementById("left_back").style.backgroundColor="#e6e0d4";



 signUp.style.backgroundColor="#e6e0d4";
 signIn.style.backgroundColor="#f98e1d";


var para=document.createElement("H2");
var para_node=document.createTextNode("Welcome to BASU online course!");
para.appendChild(para_node);
signIn.appendChild(para);

var h6=document.createElement("h6");
var h6_node=document.createTextNode("do you have account?");
h6.appendChild(h6_node);
signIn.appendChild(h6);

var button=document.createElement("button");
button.setAttribute("class","buttons");
var button_node=document.createTextNode("SIGN IN");
button.appendChild(button_node);
button.setAttribute("id","in_button");
signIn.appendChild(button);
signIn.setAttribute("class","sign_after");

var form=document.createElement("form");
var titr=document.createElement("h2");
var titr_node=document.createTextNode("CREATE ACCOUNT");
titr.appendChild(titr_node);
signUp.appendChild(titr);
form.setAttribute("class","in");
var name=document.createElement("input");
name.setAttribute("type","text");
name.setAttribute("placeholder","your name");
form.appendChild(name);
var email=document.createElement("input");
email.setAttribute("type","email");
email.setAttribute("placeholder","your email");
form.appendChild(email);
var username=document.createElement("input");
username.setAttribute("type","text");
username.setAttribute("placeholder","choose your username");
form.appendChild(username);

var password=document.createElement("input");
password.setAttribute("type","password");
password.setAttribute("placeholder","set your password!");
form.appendChild(password);

var submit=document.createElement("input");
submit.setAttribute("type","submit");
submit.setAttribute("value","create!");
// submit.setAttribute("class","subcreate");
form.appendChild(submit);


signUp.setAttribute("class","movement2");
signIn.setAttribute("class","movement");


signUp.appendChild(form);

var in_button=document.getElementById("in_button");
in_button.addEventListener("click",change2);


}




 function change2(){
    var signIn=document.getElementById("signIn");
    var signUp=document.getElementById("signUp");
    signIn.remove();
    signUp.remove();
    document.getElementById("right_back").style.backgroundColor="#e6e0d4";
    document.getElementById("left_back").style.backgroundColor="#f98e1d";

    var div_R=document.createElement("div");
    var div_L=document.createElement("div");

    div_R.setAttribute("id","sign_up");
    div_L.setAttribute("id","sign_in");

    // div_R.setAttribute("class","movement");
    // div_L.setAttribute("class","movement2");

    // document.getElementById("signUp").appendChild(div_R);
    // document.getElementById("signIn").appendChild(div_L);

    var div_up=document.createElement("div");
    var div_in=document.createElement("div");
    div_up.setAttribute("class","sign_up");
    div_in.setAttribute("class","sign_in");
    div_up.setAttribute("id","signUp");
    div_in.setAttribute("id","signIn");

    div_up.appendChild(div_R);
    div_in.appendChild(div_L);

    div_in.setAttribute("class","movement3");
    div_up.setAttribute("class","movement4");

    var titr2=document.createElement("h1");
    var titr2_node=document.createTextNode("SIGN IN");
    titr2.appendChild(titr2_node);
    div_L.appendChild(titr2);

    var social=document.createElement("ul");
    social.setAttribute("class","social");
    var social_li1=document.createElement("li");
    social_li1.setAttribute("class","social-item");
    var social_li2=document.createElement("li");
    social_li2.setAttribute("class","social-item");
    var social_li3=document.createElement("li");
    social_li3.setAttribute("class","social-item");

    var img1=document.createElement("img");
    var img2=document.createElement("img");
    var img3=document.createElement("img");

    img1.setAttribute("src","../icon/browsing.svg");
    img2.setAttribute("src","../icon/sound.svg");
    img3.setAttribute("src","../icon/heart.svg");

    var a1=document.createElement("a");
    var a2=document.createElement("a");
    var a3=document.createElement("a");

    a1.appendChild(img1);
    a2.appendChild(img2);
    a3.appendChild(img3);

    var span1=document.createElement("span");
    var span2=document.createElement("span");
    var span3=document.createElement("span");

    span1.appendChild(a1);
    span2.appendChild(a2);
    span3.appendChild(a3);

    social_li1.appendChild(span1);
    social_li2.appendChild(span2);
    social_li3.appendChild(span3);

    var div11=document.createElement("div");
    var div11_node=document.createTextNode("browse");
    div11.appendChild(div11_node);

    var div22=document.createElement("div");
    var div22_node=document.createTextNode("Radio");
    div22.appendChild(div22_node);

    var div33=document.createElement("div");
    var div33_node=document.createTextNode("Likes");
    div33.appendChild(div33_node);

    social_li1.appendChild(div11);
    social_li2.appendChild(div22);
    social_li3.appendChild(div33);

    social.appendChild(social_li1);
    social.appendChild(social_li2);
    social.appendChild(social_li3);

    a1.setAttribute("class","cur");
    a2.setAttribute("class","cur");
    a3.setAttribute("class","cur");

    div_L.appendChild(social);

    document.getElementById("")

    //sign in form 

    var form_in=document.createElement("form");
    form_in.setAttribute("class","in");

    var user_in=document.createElement("input");
    user_in.setAttribute("type","text");
    user_in.setAttribute("id","username");
    user_in.setAttribute("placeholder","User name");

    form_in.appendChild(user_in);

    var pass_in=document.createElement("input");
    pass_in.setAttribute("type","password");
    pass_in.setAttribute("id","password");
    pass_in.setAttribute("placeholder","PASSWORD");

    form_in.appendChild(pass_in);

    var sub_in=document.createElement("input");
    sub_in.setAttribute("type","submit");
    // sub_in.setAttribute("id","go");
    sub_in.setAttribute("value","GO!");

    form_in.appendChild(sub_in);

    var a_in=document.createElement("a");
    a_in_node=document.createTextNode("Forgot your password?");
    a_in.appendChild(a_in_node);

    form_in.appendChild(a_in);

    div_L.appendChild(form_in);

    //create signup card

    var h_up=document.createElement("h2");
    var h_up_node=document.createTextNode("Welcome to BASU online course!");
    h_up.appendChild(h_up_node);
    div_R.appendChild(h_up);

    var br=document.createElement("br");

    div_R.appendChild(br);

    var h6_up=document.createElement("h6");
    var h6_up_node=document.createTextNode("new here?");
    h6_up.appendChild(h6_up_node);

    div_R.appendChild(h6_up);

    var button_up=document.createElement("button");
    button_up.setAttribute("class","buttons");
    button_up.setAttribute("id","up_button");
    var button_up_node=document.createTextNode("SIGN UP");
    button_up.appendChild(button_up_node);

    div_R.appendChild(button_up);

    button_up.addEventListener("click",change);


    document.getElementById("right_back").appendChild(div_up);
    document.getElementById("left_back").appendChild(div_in);

    button_up.addEventListener("click",change);

 }